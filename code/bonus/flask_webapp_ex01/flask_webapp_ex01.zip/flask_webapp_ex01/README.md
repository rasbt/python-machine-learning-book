Sebastian Raschka, 2015

Python Machine Learning - Code Examples (Bonus Material)


# A Simple(r) Barebones Flask Webapp Template

A simple Flask app that calculates the sum of two numbers entered in the respective input fields.

You can run the app locally by executing `python app.py` within this directory.

<hr>

![](./img/img_1.png)
